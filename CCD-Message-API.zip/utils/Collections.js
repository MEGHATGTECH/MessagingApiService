exports.USER_MODEL = "User";
exports.CONVERSATION_MODEL = "Conversation";
exports.MESSEGES_MODEL = "Messages";
exports.GROUPS_MODEL = "Groups";
exports.CHANNELS_MODEL = "Channels";
exports.TAGS_MODEL = "Tags";
exports.NOTIFICATION_MODEL = "Notifications";
exports.PUSHNOTIFICATION_MODEL = "PushNotifications";